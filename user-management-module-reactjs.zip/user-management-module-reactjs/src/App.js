import React, { useState } from 'react';

// import css
import './App.css';

// import components
import UserAddRemove from './components/UserAddRemove/UserAddRemove';
import UserTable from './components/UserTable/UserTable';

function App() {

  const [userMockData, setUserMockData] = useState([]);
  const [lastCreatedUserId, setLastCreatedUserId] = useState([]);

  const getUserId = (userMockData) => {
    let _userId = 'UID';
    if (userMockData.length === 0) {
      _userId += '1';
      return _userId;
    } else {
      _userId += (Number(lastCreatedUserId.split('UID')[1]) + 1);
      return _userId;
    }
  }

  const userAddFormSubmit = (userFormDetails) => {
    let _userFormDetails = { ...userFormDetails, userId: getUserId(userMockData) };
    setLastCreatedUserId(_userFormDetails.userId);
    setUserMockData([...userMockData, _userFormDetails])
  }

  const userRemoveFormSubmit = (userId) => {
    let _userMockData = userMockData.filter((dataValue) => {
      return dataValue.userId !== userId;

    })
    setUserMockData(_userMockData);
  }

  return (
    <div className="app-wrapper">
      <UserAddRemove userAddFormSubmit={userAddFormSubmit} userRemoveFormSubmit={userRemoveFormSubmit} />
      <UserTable userData={userMockData} />
    </div>
  );
}

export default App;
