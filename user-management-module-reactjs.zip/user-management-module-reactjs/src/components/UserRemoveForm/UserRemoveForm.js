import React, { useEffect, useState } from 'react';
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input
} from 'reactstrap'


// import css
import './UserRemoveForm.css';

function UserRemoveForm({ userRemoveFormSubmit, isModelOpen, modelOpenClose }) {
  const [userId, setUserId] = useState('');

  useEffect(() => {
    setUserId('');
  }, [])

  const getInpValue = (e) => {
    setUserId(e.target.value && e.target.value.trim());
  }

  const formSubmit = () => {
    userRemoveFormSubmit(userId);
    modelOpenClose(false);
  }

  return (
    <div>
      <Modal
        isOpen={isModelOpen}
      >
        <ModalHeader toggle={() => { modelOpenClose(false) }}>
          Remove user
        </ModalHeader>
        <ModalBody>
          <Card
          >
            <CardBody>
              <Form>
                <FormGroup>
                  <Label for="UID">
                    UID
                  </Label>
                  <Input
                    id="UID"
                    name="UID"
                    placeholder="Enter user name..."
                    type="text"
                    onChange={(e) => { getInpValue(e) }}
                  />
                </FormGroup>
              </Form>
            </CardBody>
          </Card>
        </ModalBody>
        <ModalFooter>
          <Button
            color="danger"
            onClick={formSubmit}
          >
            Remove User
          </Button>
          <Button onClick={() => { modelOpenClose(false) }}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </div>
  );
}

export default UserRemoveForm;
