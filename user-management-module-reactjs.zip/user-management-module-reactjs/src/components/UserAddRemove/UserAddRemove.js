import React, { useState } from 'react';
import { Button } from 'reactstrap'


// import css
import './UserAddRemove.css';

// import components
import UserAddForm from '../UserAddForm/UserAddForm';
import UserRemoveForm from '../UserRemoveForm/UserRemoveForm';

function UserAddRemove({ userAddFormSubmit, userRemoveFormSubmit }) {
  const [isAddModelOpen, setAddModalOpenClose] = useState(false);
  const [isRemoveModelOpen, setRemoveModalOpenClose] = useState(false);

  const addModelOpenClose = (isOpen) => {
    setAddModalOpenClose(isOpen);
  }

  const removeModelOpenClose = (isOpen) => {
    setRemoveModalOpenClose(isOpen);
  }

  return (
    <div className="user-addrm-wrapper">
      <div>
        <Button
          color="primary"
          className='user-addrm-btn'
          onClick={() => { addModelOpenClose(true) }}
        >
          Add
        </Button>
        <Button
          color="danger"
          className='user-addrm-btn'
          onClick={() => { removeModelOpenClose(true) }}
        >
          Remove
        </Button>
      </div>
      <div>
        {
          isAddModelOpen &&
          <UserAddForm isModelOpen={isAddModelOpen} modelOpenClose={addModelOpenClose} userAddFormSubmit={userAddFormSubmit} />
        }
      </div>
      <div>
        {
          isRemoveModelOpen &&
          <UserRemoveForm isModelOpen={isRemoveModelOpen} modelOpenClose={removeModelOpenClose} userRemoveFormSubmit={userRemoveFormSubmit} />
        }
      </div>
    </div>
  );
}

export default UserAddRemove;
