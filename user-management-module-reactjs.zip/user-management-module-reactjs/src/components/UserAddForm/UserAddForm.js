import React, { useEffect, useState } from 'react';
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input
} from 'reactstrap'


// import css
import './UserAddForm.css';

function UserAddForm({ userAddFormSubmit, isModelOpen, modelOpenClose }) {
  const [userFormDetails, setUserFormDetails] = useState({
    userName: '',
    userEmail: '',
    userAddress: '',
    userAddress: '',
    userJoiningDate: '',
  })

  useEffect(() => {
    setUserFormDetails({
      userName: '',
      userEmail: '',
      userAddress: '',
      userAddress: '',
      userJoiningDate: '',
    });
  }, [])

  const getInpValue = (e) => {
    setUserFormDetails({
      ...userFormDetails,
      [e.target.name]: e.target.value
    });
  }

  const formSubmit = () => {
    userAddFormSubmit(userFormDetails);
    modelOpenClose(false);
  }

  return (
    <div>
      <Modal
        isOpen={isModelOpen}
      >
        <ModalHeader toggle={() => { modelOpenClose(false) }}>
          Add new user
        </ModalHeader>
        <ModalBody>
          <Card
          >
            <CardBody>
              <Form>
                <FormGroup>
                  <Label for="userName">
                    Name
                  </Label>
                  <Input
                    value={userFormDetails.userName}
                    id="userName"
                    name="userName"
                    placeholder="Enter user name..."
                    type="text"
                    onChange={(e) => { getInpValue(e) }}
                  />
                </FormGroup>
                <FormGroup>
                  <Label for="userEmail">
                    Email
                  </Label>
                  <Input
                    value={userFormDetails.userEmail}
                    id="userEmail"
                    name="userEmail"
                    placeholder="Enter user mail id..."
                    type="email"
                    onChange={(e) => { getInpValue(e) }}
                  />
                </FormGroup>
                <FormGroup>
                  <Label for="userAddress">
                    Address
                  </Label>
                  <Input
                    value={userFormDetails.userAddress}
                    id="userAddress"
                    name="userAddress"
                    placeholder="Enter user address..."
                    type="text"
                    onChange={(e) => { getInpValue(e) }}
                  />
                </FormGroup>
                <FormGroup>
                  <Label for="userJoiningDate">
                    Joining Date
                  </Label>
                  <Input
                    value={userFormDetails.userJoiningDate}
                    id="userJoiningDate"
                    name="userJoiningDate"
                    placeholder="Enter user joining date..."
                    type="date"
                    onChange={(e) => { getInpValue(e) }}
                  />
                </FormGroup>
              </Form>
            </CardBody>
          </Card>
        </ModalBody>
        <ModalFooter>
          <Button
            color="primary"
            onClick={formSubmit}
          >
            Add User
          </Button>
          <Button onClick={() => { modelOpenClose(false) }}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </div>
  );
}

export default UserAddForm;
