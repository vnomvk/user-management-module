import React from 'react';
import { Table } from 'reactstrap'

// import css
import './UserTable.css';


function UserTable({ userData }) {
  return (
    <div className="user-table-wrapper">
      <Table bordered>
        <thead>
          <tr>
            <th>
              User ID
            </th>
            <th>
              Name
            </th>
            <th>
              Email
            </th>
            <th>
              Address
            </th>
            <th>
              Joining Date
            </th>
          </tr>
        </thead>
        <tbody>
          {
            userData.length !== 0 && userData.map((dataValue) => {
              return (<tr key={dataValue.userId}>
                <th scope="row">
                  {dataValue.userId}
                </th>
                <td>
                  {dataValue.userName}
                </td>
                <td>
                  {dataValue.userEmail}
                </td>
                <td>
                  {dataValue.userAddress}
                </td>
                <td>
                  {dataValue.userJoiningDate}
                </td>
              </tr>)
            })
          }

          {
            userData.length === 0 && (<tr>
              <th scope="row">
                -
              </th>
              <td>
                -
              </td>
              <td>
                -
              </td>
              -
              <td>
                -
              </td>
            </tr>)
          }

        </tbody>
      </Table>
    </div>
  );
}

export default UserTable;
